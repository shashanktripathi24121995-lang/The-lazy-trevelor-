THE LAZY TRAVELER — Free website starter
========================================

Files:
- index.html: complete responsive website (HTML, CSS, JavaScript in one file)

Preview locally:
1. Extract the ZIP.
2. Open index.html in a web browser. An internet connection is needed for the remote photo images.

Publish free with GitHub Pages:
1. Sign in or create an account at https://github.com/
2. Create a new public repository, for example: the-lazy-traveler
3. Upload index.html (and this README if you want).
4. Open repository Settings → Pages.
5. Under Build and deployment, select “Deploy from a branch”.
6. Select branch “main” and folder “/ (root)”, then Save.
7. Wait a few minutes. GitHub will show your public website URL in the Pages section.

Customize:
- Instagram profile link is currently set to https://www.instagram.com/the_lazt_traveler/ — verify that the username is correct.
- Replace demo article text with your real travel experiences.
- Replace the demo video cards with your YouTube/Instagram links.
- Photo URLs currently load from Unsplash and need an internet connection.
- GitHub Pages hosting is free for public repositories; a custom domain is optional and usually costs money.
